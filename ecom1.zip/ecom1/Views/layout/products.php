<div class="products-sc">
<?php
   $prodtitle = "Flower wallpaper";
   $prodsd = "This is an image with a flower. It is a very beautiful flower.";
   $prodld = "";
   $prodprice = "75";
   $x = 3;
  $i = 0;
  for ($i = 0; $i < 3*$x; $i++){
  echo "
   <div class='item-cnt'>
      <img src='assets/img.jpeg' class='itm-img'>
      <div class='des-itm'>
         <a class='itm-title' href='#'><b>{$prodtitle}</b></a>
         <div class='itm-des'>
            <p>{$prodsd}</p>
         </div>
         <p><b>Price:</b></p>
         <p class='old-prce'><strike>100 rs</strike></p>
         <p class='new-prce'><b>{$prodprice} Rs</b></p>
      </div>
   </div>";
  }
   ?>
</div>
<div class="rec-sec">
      <h3>Recommended products:</h3>
      <?php
      $i = 0;
      for ($i = 0; $i < 4; $i++){
      echo '
            <div class="item-cnt-rec">
            <div class="itm-des-img">
               <div class="img-rec-div"><img src="assets/img.jpeg" class="img-rec"></div>
               <div class="des-itm-rec">
                  <a class="itm-title" href="#"><b>Flower wallpaper</b></a>
                  <div class="itm-des">
                     <p>This is an image with a flower. It is a very beautiful flower.</p>
                  </div>
               </div>
            </div>';
      }
      ?>
</div>