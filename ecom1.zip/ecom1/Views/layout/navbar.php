
   <div class="nav-bar">
      <a href="#" class="logo">e-commerce</a>
      <div class="menu">
         <a href="#" class="men-itm">Men's</a>
         <a href="#" class="men-itm">Women's</a>
         <a href="#" class="men-itm">Boy's</a>
         <a href="#" class="men-itm">Girl's</a>
         <a href="#" class="dd">
            <img src="assets/user.png" alt="" class="usr-img">
            <ul class="dropdown">
               <li class="dd-itm">
                  <a href="#">Akhilesh Janib</a>
               </li>
               <li class="dd-itm"><a href="#">My Orders</a></li>
               <li class="dd-itm"><a href="#">My Cart</a></li>
               <li class="dd-itm"><a href="#">Signout</a></li>
            </ul>
         </a>
      </div>
   </div>
