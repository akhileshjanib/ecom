<?php
    session_start();
    $url = 'localhost';
    $user = 'root';
    $password = '';
    $dbname = 'userinfo';
    $con = mysqli_connect($url, $user, $password);
    mysqli_select_db($con, $dbname);
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $ename = $_POST['ename'];
    $pname = $_POST['pname'];
    $pass1 = $_POST['pass1'];
    $pass2 = $_POST['pass2'];
    $add1 = $_POST['add1'];
    $add2 = $_POST['add2'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zipcode = $_POST['zipcode'];
    $mem = False;
    $phone = (int)($pname);
    $s = "select * from userinfo where ename='$ename' || pname='$pname'";
    echo $pname;
    if ($result = mysqli_query($con, $s)){
        $rowcount = mysqli_num_rows($result);
    }
    else{
        $rowcount = 0;
    }
    if($rowcount > 0){
        echo "User already exists";
    }
    elseif(!(phone_val())){
        echo "Enter a valid Phone Number";
    }
    elseif(!(zip_val())){
        echo "Enter a valid ZipCode";
    }
    elseif(email_val()){
        echo "Enter a valid Email";
    }
    else{
        $register = "insert into userinfo(fname, lname, ename, pname, password, add1, add2, city, state, zipcode, memb) values('$fname', '$lname', '$ename', '$pname', '$password', '$add1', '$add2', '$city', '$state', '$zipcode', '$memb')";
    }
    function phone_val(){
        $count = 0;
        while($phone == 0){
            $phone = (int)($phone/10);
            $count = $count + 1;
        }
        if (count == 10){
            return True;
        }
        else{
            return False;
        }
    }
    function email_val(){
        $x = (string)$ename;
        $x_arr = str_split($x);
        $count = 0;
        $res = True;
        for ($i = 0; $i < (count($x_arr) - 1); $i++){
            if($x_arr[$i] == '@'){
                $count = $count + 1;
            }
        }
        if ($count != 1){
            $res = False;
        }
        $xrev = strrev($x);
        $xreva = str_split($xrev, 4);
        if ($xreva[0] != 'moc.'){
            $res = False;
        }
        return $res;
    }
    function zip_val(){
        $x = (int)$zipcode;
        $count = 0;
        while($x == 0){
            $x = (int)($x/10);
            $count = $count + 1;
        }
        if (count == 6){
            return True;
        }
        else{
            return False;
        }
    }
?>