<!DOCTYPE html>
<?php
    $err = "";
?>
<html>
    <head>
        <title>Sign-Up</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/signup.css"> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <!-- Client side validation -->
        <script>
            var fname = getElementsByClassName("fname").value;
            var lname = getElementsByClassName("lname").value;
            var ename = getElementsByClassName("ename").value;
            var pname = getElementsByClassName("pname").value;
            var pass1 = getElementsByClassName("pass1").value;
            var pass2 = getElementsByClassName("pass2").value;
            var add1 = getElementsByClassName("add1").value;
            var add2 = getElementsByClassName("add2").value;
            var city = getElementsByClassName("city").value;
            var state = getElementsByClassName("state").value;
            var zipcode = getElementsByClassName("zipcode").value;
            var memb = False;
            $(document).ready(function(){
                $(".button").click(function(){
                    if(p_val() and e_val() and z_val() and pass_val()){

                    }
                })
            })
            function pass_val(){
                if (pass1 == pass2){
                    return True;
                }
            }
            function e_val(){
                var arr = ename.split();
            }
            function p_val(){

            }
            function z_val(){
                
            }

        </script>
    </head>
    <body>
        <div class="cont">
            <form action="sdb.php" method="post">
                <div class="label-cont">
                    <h2>Signup for some amazing service!</h2>  
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="fname">First Name</label></td>
                            <td><input type="text" name="fname" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="lname">Last Name</label></td>
                            <td><input type="text" name="lname" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="ename">Email</label></td>
                            <td><input type="text" name="ename" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="pname">Phone Number</label></td>
                            <td><input type="text" name="pname" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="pass1">Password</label></td>
                            <td><input type="password" name="pass1" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="pass2">Confirm Password</label></td>
                            <td><input type="password" name="pass2" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="add1">Address Line 1</label></td>
                            <td><input type="text" name="add1" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="add2">Address Line 2</label></td>
                            <td><input type="text" name="add2" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="city">City</label ></td>
                            <td><input type="text" name="city" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="state">State</label></td>
                            <td><input type="text" name="state" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td><label for="zipcode">ZipCode</label></td>
                            <td><input type="text" name="zipcode" required></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <table>
                        <tr>
                            <td></td>
                            <td><input type="submit" class="button"></td>
                        </tr>
                    </table>
                </div>
                <div class="label-cont">
                    <?php
                        echo $err;
                    ?>
                </div>
            </form>
        </div>
    </body>
</html>