<?php
	if(isset($_POST)){
		$productimage 		= $_POST['productimage'];
		$producttitle 		= $_POST['producttitle'];
		$productsd 			= $_POST['productsd'];
		$productld			= $_POST['productld'];
		$productprice 		= $_POST['productprice'];
		$category			= $_POST['category'];
			$sql = "INSERT INTO $category (firstname, lastname, email, phonenumber, password ) VALUES(?,?,?,?,?)";
			$stmtinsert = $db->prepare($sql);
			$result = $stmtinsert->execute([$firstname, $lastname, $email, $phonenumber, $password]);
			if($result){
				echo 'Successfully saved.';
			}else{
				echo 'There were errors while saving the data.';
        }
?>