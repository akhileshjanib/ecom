<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product added!</title>
    <style>
    body{
        display: flex;
        justify-content: center;
    }
        h1{
            color: greenyellow;
        }
        a{
            color: greenyellow;
            transition: 0.5s;
        }
        a:hover{
            transition: 0.5s;
            font-size: 20px;
            color: cyan;
        }
        .out{
            border: 2px solid greenyellow;
            border-radius: 20px;
            width: 500px;
            height: 300px;
            display: flex;
            justify-content: center;
        }
        .in{
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="out">
        <div class="in">
            <h1>Congratulations! Product added!</h1>
            <br>
            <a href="addprod.php">Add another product!</a></div>
    </div>
</body>
</html>