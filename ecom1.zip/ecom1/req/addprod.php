<!DOCTYPE html>
<html>
    <head>
        <title>Add product</title>
        <link rel="stylesheet" type="text/css" href="addprod.css">
    </head>
    <body>
    <div>
        <?php
            if(isset($_POST['create'])){
                echo "User registered";
            }
        ?>
    </div>
        <div>
            <form action="addprod.php" method="post">
                <div class="cont">
                    <div class="itm">
                        <table>
                             <tr>
                                <td><h4>Product Image:</h4></td>
                                <td><input type="file" name="productimage" required></td>
                            </tr>
                            <tr>
                                <td><h4>Product Title:</h4></td>
                                <td><input type="text" name="producttitle" required></td>
                            </tr>
                            <tr>
                                <td><h4>Product Short Description:</h4></td>
                                <td><input type="text" name="productsd" required></td>
                            </tr>
                            <tr>
                                <td><h4>Product Long Description:</h4></td>
                                <td><input type="text" name="productld" required></td>
                            </tr>
                            <tr>
                                <td><h4>Product Price:</h4></td>
                                <td><input type="text" name="productprice" required></td>
                            </tr>
                            <tr>
                                <td><h4>Category</h4></td>
                                <td>
                                    <select name="category" selected="" required>
                                        <option value="ladies">Ladies</option>
                                        <option value="gents">Gents</option>
                                        <option value="girls">Girls</option>
                                        <option value="boys">Boys</option>
                                    </select>
                                </td>
                            </tr>
                        </table>                  
                    </div>
                    <input type="submit" name = "create" class="sb">
                </div>
            </form>
        </div>
    </body>
</html>