<html>
    <head>
        <title>ecommerce</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="views/layout/css/style.css" />
    </head>
    <body>
        
    </body>
</html>
<?php
    include('views/layout/navbar.php')
?>
<?php
    include('views/layout/products.php')
?>